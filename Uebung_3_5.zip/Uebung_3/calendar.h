#ifndef CALENDAR_H_INCLUDED
#define CALENDAR_H_INCLUDED

void createAppointment();
void editAppointment();
void deleteAppointment();
void searchAppointment();
void sortCalendar();
void listCalendar();
void freeCalendar();
void freeAppointment();

#endif // CALENDAR_H_INCLUDED
