#ifndef TOOLS_H
   #define TOOLS_H

void waitForEnter();
void printLine(char Zeichen, int Anzahl);
int Strlen(char *str);
int askAgain(char *);
void clearBuffer();
void clearScreen();

#endif
