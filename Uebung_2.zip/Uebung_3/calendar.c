#include <stdio.h>
#include <stdlib.h>
#include "calendar.h"
#include "datastructure.h"
#include "datetime.h"
#include "tools.h"

int countAppointment = 0;
//Calendar[0] = '\0';

void createAppointment()
{
    printf("Neuen Termin anlegen\n");

    waitForEnter();
}


void editAppointment()
{
    printf("Termin bearbeiten");

    waitForEnter();
}


void deleteAppointment()
{
    printf("Termin loeschen\n");

    waitForEnter();
}


void searchAppointment()
{
    printf("Termin suchen\n");

    waitForEnter();
}



void sortCalendar()
{
    printf("Termine sortieren\n");

    waitForEnter();
}


void listCalendar()
{
    printf("Termine auflisten");

    waitForEnter();
}
