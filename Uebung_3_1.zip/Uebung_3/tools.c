#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "escapesequenzen.h"
#include "tools.h"

void printLine(char Zeichen, int Anzahl)
{
int j = 0;
for ( j = 0; j<Anzahl; j++ )
    {
        printf("%c", Zeichen);
    }
    printf("\n");
}

void waitForEnter()
{
    char Dummy;
    printf("\nBitte druecken Sie die Eingabetaste ...\n");
    do
        scanf("%c", &Dummy);
    while(Dummy !='\n');
}

int Strlen(char *str)
{
int len = 0;

while(*(str++) != '\0')
    {
        len++;
    }
    return len;
}

//Programm wiederholen
int askAgain(char *Frage)
{
char W;
printf("%s", Frage);
while (!scanf("%[jJnN]", &W))
    {
        UP_LINE;
        CLEAR_LINE;
        clearBuffer();
    }
    if (W == 'j' || W =='J')
    {
        clearBuffer();
        return 1;
    }
return 0;
}

//Zeichenpuffer loeschen
void clearBuffer()
{
   char Dummy;
   do
   {
      scanf("%c", &Dummy);
   } while (Dummy != '\n');
}


void clearScreen()
{
CLEAR;
POSITION(1, 1);
}

void falscheEingabe()
{
    POSITION(10, 1);
    FORECOLOR_RED;
    printf("   falsche Eingabe!");
    FORECOLOR_WHITE;
}

int getText(char * Titel, char **Zeiger, unsigned int Maxlen, int AllowEmpty) // Prompt = Eingabeaufforderung, Bool = 1 oder 0 -> Wahrheitswert
{
    char *Input = NULL;
    char Format[20];
    unsigned int Len = 0;

    *Zeiger = NULL; // leer machen

    Input = calloc( Maxlen , sizeof(char));
    sprintf(Format, "%%%is[^\n]", Maxlen);  //Format für folgende Benutzereingabe
    //printf("%s", Format);
    do
        {
        CLEAR_LINE;
        printf("%s ", Titel); // Titel
        scanf(Format, Input); // Eingabeaufforderung
        //printf("%s", Input);
        clearBuffer();
        Len = Strlen(Input); // die Länge der Text wird gezählt
        //printf("%i", Len);
        if((Len == 0) && AllowEmpty)
            {
            free(Input);//reservierter Speicher muss immer am Ende freigegeben werden
            return 0;
            }
        else
            {
            *Zeiger = calloc(Len+1, sizeof(char*)); // Speicher für genau der Eingegebene Text reservieren
            strcpy(*Zeiger, Input);
            //printf("%s", *Zeiger);
            free(Input);
            return 1;
            }
        }while(!Len);
    free(Input); //reservierter Speicher muss immer am Ende freigegeben werden
    return 0;
}
