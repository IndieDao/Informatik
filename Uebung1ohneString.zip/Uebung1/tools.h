#ifndef TOOLS_H
   #define TOOLS_H

int Strlen(char *str);
//int tokenize(char *text, int *Datumteil);
int askAgain(char *);
void clearBuffer();
void clearScreen();

#endif
