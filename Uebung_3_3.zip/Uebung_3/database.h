#ifndef DATABASE_H_INCLUDED
#define DATABASE_H_INCLUDED

saveCalendar();
saveAppointment();
loadCalendar();
loadAppointment();

#endif // DATABASE_H_INCLUDED
