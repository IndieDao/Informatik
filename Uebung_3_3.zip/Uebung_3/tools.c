#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "escapesequenzen.h"
#include "tools.h"

/*************************************************************************
*   Sammelort kurzer, und dynamisch einsetzbarer Funktionen
*   Die meisten Module verbessern die Benutzeroberfläche
*************************************************************************/

static char tmp[7];
static int t = 0;
//  --------------------------------------------------------------------------------
//  schreibt Teilstring (Token) bis zum Delimiter in den Zwischenstring tmp
//  und setzt die Zählvariable i auf den Wert, des nächsten Werts im Eingabestring
//  --------------------------------------------------------------------------------
void tmpToken(char *Eingabe, char Token)
{
    int z = 0;
;

    while ( (*(Eingabe + t) != Token) && (*(Eingabe + t) != '\0') )
    {
        tmp[z] = Eingabe[t];
        z++;
        t++;
    }
    tmp[z] = '\0';
    t++;
}

//  --------------------------------------------------------------------------------
//  druckt Linie aus gewünschten Zeichen in gewünschter Länge
//  --------------------------------------------------------------------------------
void printLine(char Zeichen, int Anzahl)
{
int j = 0;
for ( j = 0; j<Anzahl; j++ )
    {
        printf("%c", Zeichen);
    }
    printf("\n");
}
//  --------------------------------------------------------------------------------
//  Wartefunktion für Eingabetaste
//  --------------------------------------------------------------------------------
void waitForEnter()
{
    char Dummy;
    printf("\nBitte druecken Sie die Eingabetaste ...\n");
    do
        scanf("%c", &Dummy);
    while(Dummy !='\n');
}

int Strlen(char *str)
{
int len = 0;

while(*(str++) != '\0')
    {
        len++;
    }
    return len;
}
//  --------------------------------------------------------------------------------
//  Programm wiederholen
//  --------------------------------------------------------------------------------
int askAgain(char *Frage)
{
char W;
printf("%s", Frage);
while (!scanf("%[jJnN]", &W))
    {
        UP_LINE;
        CLEAR_LINE;
        clearBuffer();
    }
    if (W == 'j' || W =='J')
    {
        clearBuffer();
        return 1;
    }
return 0;
}
//  --------------------------------------------------------------------------------
//  Zeichenpuffer loeschen
//  --------------------------------------------------------------------------------
void clearBuffer()
{
   char Dummy;
   do
   {
      scanf("%c", &Dummy);
   } while (Dummy != '\n');
}


void clearScreen()
{
CLEAR;
POSITION(1, 1);
}
//  --------------------------------------------------------------------------------
//  schreibt "falsche Eingabe" bei Aufruf
//  --------------------------------------------------------------------------------
void falscheEingabe()
{
    POSITION(10, 1);
    FORECOLOR_RED;
    printf("   falsche Eingabe!");
    FORECOLOR_WHITE;
}

//  --------------------------------------------------------------------------------
//  Eingabefunktion schreibt eingegebenen Text von temporärem Speicher in
//  exakt großen Speicherbereich und gibt die Adresse dieses Bereichs zurück.
//  --------------------------------------------------------------------------------
int getText(char * Titel, char **Zeiger, unsigned int Maxlen, int AllowEmpty) // Prompt = Eingabeaufforderung, Bool = 1 oder 0 -> Wahrheitswert
{
    char *Input = NULL;
    char Format[20];
    unsigned int Len = 0;

    *Zeiger = NULL;                                                           // leeren

    Input = calloc( Maxlen , sizeof(char));
    sprintf(Format, "%%%i[^\n]", Maxlen);                                     // Formatiert die folgende Benutzereingabe
    //printf("%s", Format);
    do
        {
        CLEAR_LINE;
        printf("%s ", Titel); // Titel
        scanf(Format, Input); // Eingabeaufforderung
        clearBuffer();
        Len = strlen(Input); // die Länge der Text wird gezählt
        if((Len == 0) && AllowEmpty)
            {
            free(Input);//reservierter Speicher muss immer am Ende freigegeben werden
            return 0;
            }
        else
            {
            *Zeiger = calloc(Len+1, sizeof(char*)); // Speicher für genau der Eingegebene Text reservieren
            strcpy(*Zeiger, Input);
            //printf("%s", *Zeiger);
            free(Input);
            return 1;
            }
        }while(!Len);
    free(Input); //reservierter Speicher muss immer am Ende freigegeben werden
    return 0;
}
