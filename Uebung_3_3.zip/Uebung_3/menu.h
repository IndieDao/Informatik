#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

int getMenu(char *, char ** , int);

#endif // MENU_H_INCLUDED
