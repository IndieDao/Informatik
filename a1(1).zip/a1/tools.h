//
//  tools.h
//  a1
//
//  Created by BD on 07.10.16.
//  Copyright © 2016 BD. All rights reserved.
//

#ifndef tools_h
#define tools_h
#include "datastructure.h"

void clearBuffer();
int  askAgain();
void clearScreen();
void waitForEnter();
void printLine(char, int);
int  getText(char *, int, char * * , int );


#endif /* tools_h */
