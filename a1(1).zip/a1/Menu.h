//
//  Menu.h
//  a1
//
//  Created by BD on 23.10.16.
//  Copyright © 2016 BD. All rights reserved.
//

#ifndef Menu_h
#define Menu_h

int getMenu(char *, char ** , int);

#endif /* Menu_h */
